
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity ASMI_v1_0_S00_AXI is
  generic (
    C_S_AXI_DATA_WIDTH : integer := 32;
    C_S_AXI_ADDR_WIDTH : integer := 6
  );
  port (
    scsq : out std_logic;
    sclk : out std_logic;
    dq0  : out std_logic;
    dq1  : in  std_logic;

    S_AXI_ACLK    : in  std_logic;
    S_AXI_ARESETN : in  std_logic;
    S_AXI_AWADDR  : in  std_logic_vector(
      C_S_AXI_ADDR_WIDTH-1 downto 0);
    S_AXI_AWPROT  : in  std_logic_vector(2 downto 0);
    S_AXI_AWVALID : in  std_logic;
    S_AXI_AWREADY : out std_logic;
    S_AXI_WDATA   : in  std_logic_vector(
      C_S_AXI_DATA_WIDTH-1 downto 0);
    S_AXI_WSTRB   : in  std_logic_vector(
      C_S_AXI_DATA_WIDTH/8-1 downto 0);
    S_AXI_WVALID  : in  std_logic;
    S_AXI_WREADY  : out std_logic;
    S_AXI_BRESP   : out std_logic_vector(1 downto 0);
    S_AXI_BVALID  : out std_logic;
    S_AXI_BREADY  : in  std_logic;
    S_AXI_ARADDR  : in  std_logic_vector(
      C_S_AXI_ADDR_WIDTH-1 downto 0);
    S_AXI_ARPROT  : in  std_logic_vector(2 downto 0);
    S_AXI_ARVALID : in  std_logic;
    S_AXI_ARREADY : out std_logic;
    S_AXI_RDATA   : out std_logic_vector(
      C_S_AXI_DATA_WIDTH-1 downto 0);
    S_AXI_RRESP   : out std_logic_vector(1 downto 0);
    S_AXI_RVALID  : out std_logic;
    S_AXI_RREADY  : in  std_logic
  );
end entity;

architecture rtl of ASMI_v1_0_S00_AXI is

  constant REGION_SIZE : natural := 16#2C0000#;

  type base_array is array (0 to 4) of natural;

  constant REGION_BASE : base_array := (
    16#000000#,
    16#2D0000#,
    16#5A0000#,
    16#870000#,
    16#B40000#
  );

  constant RESP_OKAY :
    std_logic_vector(1 downto 0) := "00";

  constant RESP_SLVERR :
    std_logic_vector(1 downto 0) := "10";

  type state_t is (
    idle, launch, wait_high, wait_low, respond
  );

  type op_t is (
    none, program_byte, read_byte,
    erase_sector, read_status, read_id
  );

  signal state : state_t := idle;
  signal op    : op_t := none;

  signal sel : integer range 0 to 4 := 0;

  signal offs : unsigned(23 downto 0)
    := (others => '0');

  signal flash_addr :
    std_logic_vector(23 downto 0)
    := (others => '0');

  signal flash_din :
    std_logic_vector(7 downto 0)
    := (others => '0');

  signal flash_data, flash_status, flash_id :
    std_logic_vector(7 downto 0);

  signal flash_busy, flash_valid :
    std_logic;

  signal ill_wr, ill_er : std_logic;

  signal req_read, req_wr, req_er,
         req_status, req_id : std_logic := '0';

  signal aw_stored, w_stored : std_logic := '0';

  signal aw_addr :
    std_logic_vector(C_S_AXI_ADDR_WIDTH-1 downto 0)
    := (others => '0');

  signal wd :
    std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0)
    := (others => '0');

  signal ws :
    std_logic_vector(C_S_AXI_DATA_WIDTH/8-1 downto 0)
    := (others => '0');

  signal bvalid_i : std_logic := '0';
  signal bresp_i :
    std_logic_vector(1 downto 0) := RESP_OKAY;

  signal rvalid_i : std_logic := '0';
  signal rresp_i :
    std_logic_vector(1 downto 0) := RESP_OKAY;

  signal rdata_i :
    std_logic_vector(31 downto 0)
    := (others => '0');

  signal result_byte :
    std_logic_vector(7 downto 0)
    := (others => '0');

  signal last_valid, last_error : std_logic := '0';

  signal awready_i, wready_i, arready_i :
    std_logic;

begin

  assert C_S_AXI_DATA_WIDTH = 32
    report "AXI data width must be 32"
    severity failure;

  assert C_S_AXI_ADDR_WIDTH >= 5
    report "AXI address width must be >=5"
    severity failure;

  ----------------------------------------------------------------
  -- MT25QL128ABA SPI CONTROLLER INSTANTIATION
  ----------------------------------------------------------------
  U_SPI : entity work.ASMI
    generic map (
      CS_GAP_CLKS    => 10,
      SPI_ENABLE_DIV => 2
    )
    port map (
      reset => not S_AXI_ARESETN,
      clkin => S_AXI_ACLK,

      read         => req_read,
      rden         => '1',
      addr         => flash_addr,
      read_status  => req_status,
      write        => req_wr,
      datain       => flash_din,
      sector_erase => req_er,
      bulk_erase   => '0',
      read_rdid    => req_id,

      dataout       => flash_data,
      busy          => flash_busy,
      data_valid    => flash_valid,
      status_out    => flash_status,
      illegal_write => ill_wr,
      illegal_erase => ill_er,
      rdid_out      => flash_id,

      scsq => scsq,
      sclk => sclk,
      dq0  => dq0,
      dq1  => dq1
    );

  ----------------------------------------------------------------
  -- AXI4-LITE INTERFACE
  ----------------------------------------------------------------
  awready_i <= '1'
    when aw_stored = '0'
    and state = idle
    and bvalid_i = '0'
    else '0';

  wready_i <= '1'
    when w_stored = '0'
    and state = idle
    and bvalid_i = '0'
    else '0';

  S_AXI_AWREADY <= awready_i;
  S_AXI_WREADY  <= wready_i;

  S_AXI_BVALID <= bvalid_i;
  S_AXI_BRESP  <= bresp_i;

  arready_i <= not rvalid_i;

  S_AXI_ARREADY <= arready_i;
  S_AXI_RVALID  <= rvalid_i;
  S_AXI_RRESP   <= rresp_i;
  S_AXI_RDATA   <= rdata_i;

  ----------------------------------------------------------------
  -- AXI WRITE + FLASH OPERATIONS
  ----------------------------------------------------------------
  process(S_AXI_ACLK)
    variable regno : natural range 0 to 7;
    variable abs_address : natural;
  begin
    if rising_edge(S_AXI_ACLK) then

      req_read   <= '0';
      req_wr     <= '0';
      req_er     <= '0';
      req_status <= '0';
      req_id     <= '0';

      if S_AXI_ARESETN = '0' then

        state <= idle;
        op <= none;
        sel <= 0;
        offs <= (others => '0');

        aw_stored <= '0';
        w_stored  <= '0';

        aw_addr <= (others => '0');
        wd <= (others => '0');
        ws <= (others => '0');

        bvalid_i <= '0';
        bresp_i  <= RESP_OKAY;

        flash_addr <= (others => '0');
        flash_din  <= (others => '0');

        result_byte <= (others => '0');
        last_valid <= '0';
        last_error <= '0';

      else

        if bvalid_i = '1'
          and S_AXI_BREADY = '1' then
          bvalid_i <= '0';
        end if;

        if awready_i = '1'
          and S_AXI_AWVALID = '1' then
          aw_addr <= S_AXI_AWADDR;
          aw_stored <= '1';
        end if;

        if wready_i = '1'
          and S_AXI_WVALID = '1' then
          wd <= S_AXI_WDATA;
          ws <= S_AXI_WSTRB;
          w_stored <= '1';
        end if;

        case state is

          when idle =>

            if aw_stored = '1'
              and w_stored = '1'
              and bvalid_i = '0' then

              aw_stored <= '0';
              w_stored <= '0';

              regno := to_integer(
                unsigned(aw_addr(4 downto 2)));

              bresp_i <= RESP_OKAY;

              case regno is

                -- 0x00: FPGA SELECT
                when 0 =>
                  if ws = "1111" and
                    unsigned(wd) <= to_unsigned(4,32) then

                    sel <= to_integer(
                      unsigned(wd(2 downto 0)));

                    state <= respond;
                  else
                    last_error <= '1';
                    bresp_i <= RESP_SLVERR;
                    state <= respond;
                  end if;

                -- 0x04: REGION OFFSET
                when 1 =>
                  if ws = "1111" and
                    unsigned(wd) <
                      to_unsigned(REGION_SIZE,32) then

                    offs <= unsigned(wd(23 downto 0));
                    state <= respond;
                  else
                    last_error <= '1';
                    bresp_i <= RESP_SLVERR;
                    state <= respond;
                  end if;

                -- 0x08: WRITE ONE BYTE
                when 2 =>
                  if ws = "0001" and
                    offs < to_unsigned(REGION_SIZE,24) then

                    abs_address :=
                      REGION_BASE(sel) + to_integer(offs);

                    flash_addr <= std_logic_vector(
                      to_unsigned(abs_address,24));

                    flash_din <= wd(7 downto 0);

                    last_valid <= '0';
                    last_error <= '0';

                    op <= program_byte;
                    state <= launch;
                  else
                    last_error <= '1';
                    bresp_i <= RESP_SLVERR;
                    state <= respond;
                  end if;

                -- 0x0C: COMMAND
                when 3 =>
                  if ws /= "0001" then
                    last_error <= '1';
                    bresp_i <= RESP_SLVERR;
                    state <= respond;
                  else
                    abs_address :=
                      REGION_BASE(sel) + to_integer(offs);

                    flash_addr <= std_logic_vector(
                      to_unsigned(abs_address,24));

                    case wd(7 downto 0) is

                      when x"01" =>
                        if offs <
                          to_unsigned(REGION_SIZE,24) then
                          op <= read_byte;
                          last_valid <= '0';
                          state <= launch;
                        else
                          last_error <= '1';
                          bresp_i <= RESP_SLVERR;
                          state <= respond;
                        end if;

                      when x"02" =>
                        if offs <
                          to_unsigned(REGION_SIZE,24) then
                          op <= erase_sector;
                          last_error <= '0';
                          state <= launch;
                        else
                          last_error <= '1';
                          bresp_i <= RESP_SLVERR;
                          state <= respond;
                        end if;

                      when x"03" =>
                        op <= read_status;
                        last_valid <= '0';
                        state <= launch;

                      when x"04" =>
                        op <= read_id;
                        last_valid <= '0';
                        state <= launch;

                      when others =>
                        last_error <= '1';
                        bresp_i <= RESP_SLVERR;
                        state <= respond;
                    end case;
                  end if;

                when others =>
                  last_error <= '1';
                  bresp_i <= RESP_SLVERR;
                  state <= respond;

              end case;
            end if;

          -- Generate one-clock request
          when launch =>
            case op is
              when program_byte =>
                req_wr <= '1';
              when read_byte =>
                req_read <= '1';
              when erase_sector =>
                req_er <= '1';
              when read_status =>
                req_status <= '1';
              when read_id =>
                req_id <= '1';
              when others =>
                null;
            end case;

            state <= wait_high;

          -- Wait for SPI core to accept
          when wait_high =>
            if flash_busy = '1' then
              state <= wait_low;
            end if;

          -- Wait for SPI core to complete
          when wait_low =>
            if flash_busy = '0' then

              if op = program_byte then
                offs <= offs + 1;

              elsif op = read_byte then
                result_byte <= flash_data;
                last_valid <= '1';

              elsif op = read_status then
                result_byte <= flash_status;
                last_valid <= '1';

              elsif op = read_id then
                result_byte <= flash_id;
                last_valid <= '1';
              end if;

              if (op = program_byte and ill_wr = '1') or
                 (op = erase_sector and ill_er = '1') then

                last_error <= '1';
                bresp_i <= RESP_SLVERR;
              end if;

              state <= respond;
            end if;

          when respond =>
            bvalid_i <= '1';
            state <= idle;

        end case;
      end if;
    end if;
  end process;

  ----------------------------------------------------------------
  -- AXI READ REGISTER INTERFACE
  ----------------------------------------------------------------
  process(S_AXI_ACLK)
    variable rd : natural range 0 to 7;
    variable temp : std_logic_vector(31 downto 0);
  begin
    if rising_edge(S_AXI_ACLK) then

      if S_AXI_ARESETN = '0' then
        rdata_i <= (others => '0');
        rresp_i <= RESP_OKAY;
        rvalid_i <= '0';

      else
        if rvalid_i = '1'
          and S_AXI_RREADY = '1' then
          rvalid_i <= '0';
        end if;

        if arready_i = '1'
          and S_AXI_ARVALID = '1' then

          rd := to_integer(
            unsigned(S_AXI_ARADDR(4 downto 2)));

          temp := (others => '0');
          rresp_i <= RESP_OKAY;

          case rd is

            when 0 =>
              temp(2 downto 0) :=
                std_logic_vector(to_unsigned(sel,3));

            when 1 =>
              temp(23 downto 0) :=
                std_logic_vector(offs);

            when 2 =>
              temp(7 downto 0) := flash_din;

            when 4 =>
              temp(7 downto 0) := result_byte;

            when 5 =>
              temp(0) := flash_busy;

              if state /= idle
                or bvalid_i = '1'
                or aw_stored = '1'
                or w_stored = '1' then
                temp(0) := '1';
              end if;

              temp(1) := last_error;
              temp(2) := last_valid;

            when 6 =>
              temp(7 downto 0) := flash_status;

            when 7 =>
              temp(7 downto 0) := flash_id;

            when others =>
              rresp_i <= RESP_SLVERR;

          end case;

          rdata_i <= temp;
          rvalid_i <= '1';
        end if;
      end if;
    end if;
  end process;

end architecture;
