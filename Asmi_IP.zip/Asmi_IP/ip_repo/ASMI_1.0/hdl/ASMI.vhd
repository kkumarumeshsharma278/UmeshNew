----------------------------------------------------------------------------------
-- MT25QL128ABA 128 Mbit Micron SPI NOR controller, standard SPI 1-1-1.
-- Coding style: adc2lane (GENERIC, state/next_state, scmb_proc, sseq_proc).
-- SPI mode 0: SCLK LOW idle, DQ0=MOSI output, DQ1=MISO input.
-- Internally generated spi_clkp clock-enable advances the SPI state machine.
-- Timing: DQ0 stable before rising SCLK; DQ1 sampled after HIGH interval.
-- Commands: 03 READ, 05 RDSR, 9F RDID first byte, 06 WREN,
--           02 PP one byte, D8 erase 64KB, C7 bulk erase.
-- WREN and WIP polling are automatic for program/erase operations.
-- CS_GAP_CLKS: minimum CS# HIGH time in bclk cycles. Choose >=
--              ceil(50 ns * bclk frequency) for non-READ operations.
-- No startup configuration, flag-status error checks or polling timeout.
-- illegal_write and illegal_erase are placeholders tied LOW.
-- Holding a request high triggers subsequent operations after busy returns LOW.
-- Apply reset before first use; clkin must meet SPI timing specifications.
-- SPI_ENABLE_DIV controls enable-pulse spacing (SCLK ~= clkin/(3*DIV) during bit transfer).
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ASMI is
    GENERIC (
        CS_GAP_CLKS : POSITIVE := 10;
        SPI_ENABLE_DIV : POSITIVE := 2
    );
    Port (
        reset          : in  STD_LOGIC; -- active HIGH, matches block diagram
        clkin          : in  STD_LOGIC; -- bclk equivalent
        read           : in  STD_LOGIC;
        rden           : in  STD_LOGIC;
        addr           : in  STD_LOGIC_VECTOR(23 downto 0);
        read_status    : in  STD_LOGIC;
        write          : in  STD_LOGIC;
        datain         : in  STD_LOGIC_VECTOR(7 downto 0);
        sector_erase   : in  STD_LOGIC;
        bulk_erase     : in  STD_LOGIC;
        read_rdid      : in  STD_LOGIC;
        dataout        : out STD_LOGIC_VECTOR(7 downto 0);
        busy           : out STD_LOGIC;
        data_valid     : out STD_LOGIC;
        status_out     : out STD_LOGIC_VECTOR(7 downto 0);
        illegal_write  : out STD_LOGIC;
        illegal_erase  : out STD_LOGIC;
        rdid_out       : out STD_LOGIC_VECTOR(7 downto 0);
        scsq           : out STD_LOGIC; -- CS# active LOW
        sclk           : out STD_LOGIC;
        dq0            : out STD_LOGIC; -- MOSI
        dq1            : in  STD_LOGIC  -- MISO
    );
end entity ASMI;

architecture Behavioral of ASMI is
    type state_type IS (sidle, sstartx, sclk_lo, sclk_hi, sbit_end,
                        sbyte_end, sstop_lo, sstop_hi, sfinish);
    SIGNAL state, next_state : state_type := sidle;

    type op_type IS (op_read, op_status, op_rdid, op_write, op_sector, op_bulk);
    SIGNAL op : op_type := op_read;
    type stage_type IS (stage_wren, stage_main, stage_poll);
    SIGNAL stage : stage_type := stage_main;
    type phase_type IS (phase_cmd, phase_addr, phase_tx, phase_rx);
    SIGNAL phase : phase_type := phase_cmd;

    SIGNAL tx_buf, rd_buf : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    SIGNAL addr_buf : STD_LOGIC_VECTOR(23 downto 0) := (others => '0');
    SIGNAL datain_buf : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    SIGNAL data_buf, status_buf, id_buf : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    SIGNAL bit_count : INTEGER RANGE 0 TO 7 := 7;
    SIGNAL addr_count : INTEGER RANGE 0 TO 2 := 2;
    SIGNAL gap_count : INTEGER RANGE 0 TO CS_GAP_CLKS := 0;
    SIGNAL sclk_i, dq0_i : STD_LOGIC := '0';
    SIGNAL scsq_i : STD_LOGIC := '1';
    SIGNAL spi_clkp : STD_LOGIC := '0';
    SIGNAL spi_div_count : INTEGER RANGE 0 TO SPI_ENABLE_DIV - 1 := 0;
    SIGNAL valid_i : STD_LOGIC := '0';

    function cmd_of(o : op_type) return STD_LOGIC_VECTOR is
    begin
        case o is
            when op_read   => return x"03";
            when op_status => return x"05";
            when op_rdid   => return x"9F";
            when op_write  => return x"02";
            when op_sector => return x"D8";
            when op_bulk   => return x"C7";
        end case;
    end function;
begin
    -- A clock-enable pulse, not an independently generated clock.
    spi_clk_enable_proc : process(clkin)
    begin
        if rising_edge(clkin) then
            if reset = '1' then
                spi_div_count <= 0;
                spi_clkp <= '0';
            elsif spi_div_count = SPI_ENABLE_DIV - 1 then
                spi_div_count <= 0;
                spi_clkp <= '1';
            else
                spi_div_count <= spi_div_count + 1;
                spi_clkp <= '0';
            end if;
        end if;
    end process;

    sclk <= sclk_i;
    scsq <= scsq_i;
    dq0 <= dq0_i;
    dataout <= data_buf;
    status_out <= status_buf;
    rdid_out <= id_buf;
    data_valid <= valid_i;
    busy <= '0' when state = sidle else '1';
    -- These outputs require explicit protection/error-checking logic to implement.
    illegal_write <= '0';
    illegal_erase <= '0';

    -- SPI waveform FSM: set MOSI with clock LOW; raise clock; sample MISO
    -- after the full HIGH interval, while lowering SCLK on the same bclk edge.
    scmb_proc : PROCESS(state, bit_count)
    BEGIN
        next_state <= state;
        CASE state IS
            WHEN sidle     => next_state <= sidle;
            WHEN sstartx   => next_state <= sclk_lo;
            WHEN sclk_lo   => next_state <= sclk_hi;
            WHEN sclk_hi   => next_state <= sbit_end;
            WHEN sbit_end  =>
                IF bit_count = 0 THEN
                    next_state <= sbyte_end;
                ELSE
                    next_state <= sclk_lo;
                END IF;
            WHEN sbyte_end => next_state <= sstartx;
            WHEN sstop_lo  => next_state <= sstop_hi;
            WHEN sstop_hi  => next_state <= sfinish;
            WHEN sfinish   => next_state <= sidle;
        END CASE;
    END PROCESS scmb_proc;

    sseq_proc : PROCESS(clkin)
        variable next_tx : STD_LOGIC_VECTOR(7 downto 0);
        variable next_phase : phase_type;
        variable more_bytes : boolean;
        variable done_bytes : boolean;
        variable next_stage : stage_type;
        variable again : boolean;
    BEGIN
        IF rising_edge(clkin) THEN
            IF reset = '1' THEN
                state <= sidle;
                sclk_i <= '0';
                scsq_i <= '1';
                dq0_i <= '0';
                valid_i <= '0';
                data_buf <= (others => '0');
                status_buf <= (others => '0');
                id_buf <= (others => '0');
                tx_buf <= (others => '0');
                rd_buf <= (others => '0');
                bit_count <= 7;
                addr_count <= 2;
                gap_count <= 0;
                phase <= phase_cmd;
                stage <= stage_main;
            ELSE
                valid_i <= '0';
                IF state = sidle THEN
                    -- One request accepted only when idle; priority top to bottom.
                    IF read = '1' OR read_status = '1' OR write = '1' OR
                       sector_erase = '1' OR bulk_erase = '1' OR read_rdid = '1' THEN
                        IF read = '1' THEN
                            op <= op_read; next_tx := x"03";
                            stage <= stage_main;
                        ELSIF read_status = '1' THEN
                            op <= op_status; next_tx := x"05";
                            stage <= stage_main;
                        ELSIF write = '1' THEN
                            op <= op_write; next_tx := x"06";
                            stage <= stage_wren;
                        ELSIF sector_erase = '1' THEN
                            op <= op_sector; next_tx := x"06";
                            stage <= stage_wren;
                        ELSIF bulk_erase = '1' THEN
                            op <= op_bulk; next_tx := x"06";
                            stage <= stage_wren;
                        ELSE
                            op <= op_rdid; next_tx := x"9F";
                            stage <= stage_main;
                        END IF;
                        addr_buf <= addr;
                        datain_buf <= datain;
                        tx_buf <= next_tx;
                        rd_buf <= (others => '0');
                        phase <= phase_cmd;
                        bit_count <= 7;
                        addr_count <= 2;
                        scsq_i <= '0';
                        sclk_i <= '0';
                        dq0_i <= next_tx(7);
                        state <= sstartx;
                    END IF;
                ELSIF state = sfinish THEN
                    -- CS# must remain HIGH for CS_GAP_CLKS full clkin cycles.
                    IF gap_count > 0 THEN
                        gap_count <= gap_count - 1;
                    ELSE
                        again := false;
                        next_tx := (others => '0');
                        next_stage := stage;
                        IF stage = stage_wren THEN
                            again := true;
                            next_stage := stage_main;
                            next_tx := cmd_of(op);
                        ELSIF stage = stage_main AND
                              (op = op_write OR op = op_sector OR op = op_bulk) THEN
                            again := true;
                            next_stage := stage_poll;
                            next_tx := x"05";
                        ELSIF stage = stage_poll AND rd_buf(0) = '1' THEN
                            again := true;
                            next_stage := stage_poll;
                            next_tx := x"05";
                        END IF;
                        IF again THEN
                            stage <= next_stage;
                            phase <= phase_cmd;
                            tx_buf <= next_tx;
                            bit_count <= 7;
                            addr_count <= 2;
                            rd_buf <= (others => '0');
                            dq0_i <= next_tx(7);
                            sclk_i <= '0';
                            scsq_i <= '0';
                            state <= sstartx;
                        ELSE
                            state <= sidle;
                        END IF;
                    END IF;
                ELSIF spi_clkp = '1' THEN
                    CASE state IS
                        WHEN sstartx =>
                            -- Keep CS# low, SCLK low with MOSI already set.
                            sclk_i <= '0';
                            dq0_i <= tx_buf(7);
                            state <= next_state;
                        WHEN sclk_lo =>
                            sclk_i <= '0';
                            dq0_i <= tx_buf(bit_count);
                            state <= next_state;
                        WHEN sclk_hi =>
                            sclk_i <= '1';
                            state <= next_state;
                        WHEN sbit_end =>
                            -- MISO sampled after HIGH half-cycle, before SCLK falls.
                            IF phase = phase_rx THEN
                                rd_buf(bit_count) <= dq1;
                            END IF;
                            sclk_i <= '0';
                            IF bit_count /= 0 THEN
                                bit_count <= bit_count - 1;
                            END IF;
                            state <= next_state;
                        WHEN sbyte_end =>
                            more_bytes := false;
                            done_bytes := false;
                            next_phase := phase;
                            next_tx := (others => '0');
                            IF phase = phase_cmd THEN
                                IF stage = stage_wren THEN
                                    done_bytes := true;
                                ELSIF stage = stage_poll OR op = op_status OR op = op_rdid THEN
                                    next_phase := phase_rx;
                                    more_bytes := true;
                                ELSIF op = op_bulk THEN
                                    done_bytes := true;
                                ELSE
                                    next_phase := phase_addr;
                                    next_tx := addr_buf(23 downto 16);
                                    addr_count <= 2;
                                    more_bytes := true;
                                END IF;
                            ELSIF phase = phase_addr THEN
                                IF addr_count = 2 THEN
                                    next_tx := addr_buf(15 downto 8);
                                    addr_count <= 1;
                                    more_bytes := true;
                                ELSIF addr_count = 1 THEN
                                    next_tx := addr_buf(7 downto 0);
                                    addr_count <= 0;
                                    more_bytes := true;
                                ELSIF op = op_read THEN
                                    next_phase := phase_rx;
                                    more_bytes := true;
                                ELSIF op = op_write THEN
                                    next_phase := phase_tx;
                                    next_tx := datain_buf;
                                    more_bytes := true;
                                ELSE
                                    done_bytes := true;
                                END IF;
                            ELSIF phase = phase_rx THEN
                                IF stage = stage_poll THEN
                                    status_buf <= rd_buf;
                                ELSIF op = op_read THEN
                                    IF rden = '1' THEN
                                        data_buf <= rd_buf;
                                        valid_i <= '1';
                                    END IF;
                                ELSIF op = op_status THEN
                                    status_buf <= rd_buf;
                                    valid_i <= '1';
                                ELSIF op = op_rdid THEN
                                    id_buf <= rd_buf;
                                    valid_i <= '1';
                                END IF;
                                done_bytes := true;
                            ELSE
                                -- One data byte for the write request.
                                done_bytes := true;
                            END IF;
                            IF more_bytes THEN
                                tx_buf <= next_tx;
                                phase <= next_phase;
                                bit_count <= 7;
                                rd_buf <= (others => '0');
                                dq0_i <= next_tx(7);
                                state <= next_state;
                            ELSIF done_bytes THEN
                                state <= sstop_lo;
                            END IF;
                        WHEN sstop_lo =>
                            sclk_i <= '0';
                            scsq_i <= '1';
                            gap_count <= CS_GAP_CLKS;
                            state <= next_state;
                        WHEN sstop_hi =>
                            state <= next_state;
                        WHEN others =>
                            state <= sidle;
                    END CASE;
                END IF;
            END IF;
        END IF;
    END PROCESS sseq_proc;
end Behavioral;
